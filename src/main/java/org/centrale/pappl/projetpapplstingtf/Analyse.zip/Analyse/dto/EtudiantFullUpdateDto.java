package org.centrale.pappl.projetpapplstingtf.soutenance.dto;

public record EtudiantFullUpdateDto(
    // Etudiant
    String nom,
    String prenom,

    // Stage
    String titre,
    String dateDebut,   // "yyyy-MM-dd HH:mm:ss" ou null
    String dateFin,     // idem
    String typeStage,
    Boolean signee,
    String annee,
    Integer entrepriseId,  // FK vers Entreprise, nullable

    // Soutenance
    Boolean confidentiel,
    Boolean maitreStage,
    String note,        // texte pour laisser vide ou décimal parseable
    Boolean reponse,
    Integer statutId     // FK vers Statut, peut être requis si création
) {}
