/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.centrale.pappl.projetpapplstingtf.soutenance.dao;

/**
 *
 * @author anas-
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import org.centrale.pappl.projetpapplstingtf.soutenance.dto.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Repository // Annotation Spring indiquant que cette classe est un DAO (Data Access Object)
public class EtudiantDao {

    private final JdbcTemplate jdbc;
// @Qualifier("jdbcSoutenance") permet de spécifier quel bean JdbcTemplate utiliser

    public EtudiantDao(@Qualifier("jdbcSoutenance") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<EtudiantDto> findAllForList() {
        String sql = """
            SELECT e.id_etudiant AS id,
                   e.nom,
                   e.prenom,
                   s.type_stage,
                   en.nom AS entreprise
            FROM etudiant e
            JOIN stage s        ON s.id_etudiant = e.id_etudiant
            JOIN entreprise en  ON en.id_entreprise = s.id_entreprise
            ORDER BY e.nom, e.prenom
        """;
        // Exécution de la requête SQL avec JdbcTemplate
        // La méthode query() exécute la requête et transforme chaque ligne en objet EtudiantDto
//        (rs, i) -> new EtudiantDto(...) est un lambda expression qui transforme chaque ligne du résultat en objet EtudiantDto
        return jdbc.query(sql, (rs, i) -> new EtudiantDto(
                rs.getInt("id"),
                rs.getString("nom"),
                rs.getString("prenom"),
                rs.getString("type_stage"),
                rs.getString("entreprise")
        ));
    }

    public Optional<EtudiantDto> findById(int id) {
        // Vérifie les NOMS EXACTS dans ta BD : Etudiant / id_etudiante / type_stage / Entreprise / id_entreprise / nom
        final String sql = """
            SELECT e.id_etudiant AS id,
                   e.nom,
                   e.prenom,
                   s.type_stage,
                   en.nom AS entreprise
            FROM Etudiant e
            LEFT JOIN Stage s        ON s.id_etudiant   = e.id_etudiant
            LEFT JOIN Entreprise en  ON en.id_entreprise = s.id_entreprise
            WHERE e.id_etudiant = ?
            LIMIT 1
        """;
        try {
            EtudiantDto dto = jdbc.queryForObject(
                    sql,
                    (rs, i) -> new EtudiantDto(
                            rs.getInt("id"),
                            rs.getString("nom"),
                            rs.getString("prenom"),
                            rs.getString("type_stage"),
                            rs.getString("entreprise")
                    ),
                    id
            );
            return Optional.ofNullable(dto);
        } catch (EmptyResultDataAccessException ex) {
            return Optional.empty(); // 0 ligne → 404 côté contrôleur
        }
    }

    private static LocalDateTime ldt(ResultSet rs, String col) throws SQLException {
        Timestamp ts = rs.getTimestamp(col);
        return (ts == null) ? null : ts.toLocalDateTime();
    }

    public Optional<EtudiantFullDto> queryMain(int idEtudiant) {
        final String sql = """
            SELECT
                e.nom                              AS e_nom,
                e.prenom                           AS e_prenom,
                -- Stage
                s.titre                            AS s_titre,
                s.date_debut                       AS s_date_debut,
                s.date_fin                         AS s_date_fin,
                s.type_stage                       AS s_type_stage,
                s.signee                           AS s_signee,
                s.annee                            AS s_annee,
                en.nom                             AS en_nom,
                -- Soutenance
                so.confidentiel                    AS so_confidentiel,
                so.maitre_stage                    AS so_maitre_stage,
                so.note                            AS so_note,
                so.reponse                         AS so_reponse,
                st.nom                             AS st_nom
            FROM Etudiant e
            LEFT JOIN Stage       s  ON s.id_etudiant   = e.id_etudiant
            LEFT JOIN Entreprise  en ON en.id_entreprise = s.id_entreprise
            LEFT JOIN Soutenance  so ON so.id_stage     = s.id_stage
            LEFT JOIN Statut      st ON st.id_statut    = so.id_statut
            WHERE e.id_etudiant = ?
            LIMIT 1
        """;

        List<EtudiantFullDto> rows = jdbc.query(sql, (rs, rowNum) -> {
            // on crée un full DTO "partiel", listes vides pour l’instant
            EtudiantFullDto dto = new EtudiantFullDto(
                    rs.getString("e_nom"),
                    rs.getString("e_prenom"),
                    
                    rs.getString("s_titre"),
                    ldt(rs, "s_date_debut"), // erreur 
                    ldt(rs, "s_date_fin"), // erreur 
                    rs.getString("s_type_stage"),
                    (Boolean) rs.getObject("s_signee"),
                    rs.getString("s_annee"),
                    rs.getString("en_nom"),
                    (Boolean) rs.getObject("so_confidentiel"),
                    (Boolean) rs.getObject("so_maitre_stage"),
                    rs.getBigDecimal("so_note"),
                    (Boolean) rs.getObject("so_reponse"),
                    rs.getString("st_nom"),
                    List.of(),
                    List.of()
            );
            return dto;
        }, idEtudiant);

        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    // 2.2 Présentations (0..n lignes)
    private List<PresentationDto> queryPresentations(int idEtudiant) {
        final String sql = """
            SELECT
                pr.type_lieu         AS p_type,
                l.nom                AS p_lieu,
                pr.date_presentee    AS p_date,
                pr.heure             AS p_heure
            FROM Etudiant e
            JOIN Stage      s  ON s.id_etudiant   = e.id_etudiant
            JOIN Soutenance so ON so.id_stage     = s.id_stage
            LEFT JOIN Presentee pr ON pr.id_soutenance = so.id_soutenance
            LEFT JOIN Lieu      l  ON l.id_lieu        = pr.id_lieu
            WHERE e.id_etudiant = ?
            ORDER BY pr.date_presentee NULLS LAST, pr.heure NULLS LAST
        """;

        return jdbc.query(sql, (rs, i) -> new PresentationDto(
                rs.getString("p_type"),
                rs.getString("p_lieu"),
                ldt(rs, "p_date"), // erreur 
                ldt(rs, "p_heure") //erreur 
        ), idEtudiant);
    }

    // 2.3 Jury (0..n lignes)
    private List<JuryDto> queryJury(int idEtudiant) {
        final String sql = """
            SELECT
                p.nom    AS j_nom,
                p.prenom AS j_prenom,
                p.login  AS j_login,
                r.type   AS j_role
            FROM Etudiant e
            JOIN Stage        s  ON s.id_etudiant   = e.id_etudiant
            JOIN Soutenance   so ON so.id_stage     = s.id_stage
            LEFT JOIN Participer pa ON pa.id_soutenance = so.id_soutenance
            LEFT JOIN Professeur p  ON p.id_responsable = pa.id_responsable
            LEFT JOIN Role_prof r   ON r.id_role        = pa.id_role
            WHERE e.id_etudiant = ?
            ORDER BY j_role, j_nom, j_prenom
        """;

        return jdbc.query(sql, (rs, i) -> new JuryDto(
                rs.getString("j_nom"),
                rs.getString("j_prenom"),
                rs.getString("j_login"),
                rs.getString("j_role")
        ), idEtudiant);
    }

    // 2.4 API publique
    public Optional<EtudiantFullDto> findFullById(int idEtudiant) {
        Optional<EtudiantFullDto> base = queryMain(idEtudiant);
        if (base.isEmpty()) {
            return Optional.empty();
        }

        List<PresentationDto> pres = queryPresentations(idEtudiant);
        List<JuryDto> jury = queryJury(idEtudiant);

        EtudiantFullDto b = base.get();
        EtudiantFullDto merged = new EtudiantFullDto(
                b.nom(), b.prenom(),
                b.titre(), b.dateDebut(), b.dateFin(), b.typeStage(), b.signee(), b.annee(), b.entreprise(),
                b.confidentiel(), b.maitreStage(), b.note(), b.reponse(), b.statut(),
                pres, jury
        );
        return Optional.of(merged);
    }

    public int updateIdentite(int id, String nom, String prenom) {
        final String sql = "UPDATE Etudiant SET nom = ?, prenom = ? WHERE id_etudiant = ?";
        return jdbc.update(sql, nom, prenom, id);
    }

    public int updateTypeStage(int id, String typeStage) {
        final String sql = "UPDATE Stage SET type_stage = ? WHERE id_etudiant = ?";
        return jdbc.update(sql, typeStage, id);
    }
    
    
    public Integer findStageIdByEtudiant(int idEtudiant) {
    return jdbc.query("""
        SELECT id_stage FROM Stage
        WHERE id_etudiant = ?
        ORDER BY id_stage DESC
        LIMIT 1
    """, rs -> rs.next() ? rs.getInt("id_stage") : null, idEtudiant);
}

public Integer insertStage(int idEtudiant, String titre, java.time.LocalDateTime debut, java.time.LocalDateTime fin,
                           String typeStage, Boolean signee, String annee, Integer entrepriseId) {
    // NOT NULL: titre, date_debut, date_fin
    jdbc.update("""
        INSERT INTO Stage (titre, date_debut, date_fin, type_stage, signee, annee, id_entreprise, id_etudiant)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, titre, debut, fin, typeStage, signee, annee, entrepriseId, idEtudiant);

    return jdbc.queryForObject("SELECT currval(pg_get_serial_sequence('stage','id_stage'))", Integer.class);
}

public int updateStage(int idStage, String titre, java.time.LocalDateTime debut, java.time.LocalDateTime fin,
                       String typeStage, Boolean signee, String annee, Integer entrepriseId) {
    return jdbc.update("""
        UPDATE Stage
        SET titre = ?, date_debut = ?, date_fin = ?, type_stage = ?, signee = ?, annee = ?, id_entreprise = ?
        WHERE id_stage = ?
    """, titre, debut, fin, typeStage, signee, annee, entrepriseId, idStage);
}

public Integer findSoutenanceIdByStage(int idStage) {
    return jdbc.query("""
        SELECT id_soutenance FROM Soutenance WHERE id_stage = ? LIMIT 1
    """, rs -> rs.next() ? rs.getInt("id_soutenance") : null, idStage);
}

public Integer insertSoutenance(int idStage, Boolean confidentiel, Boolean maitreStage,
                                java.math.BigDecimal note, Boolean reponse, Integer statutId) {
    jdbc.update("""
        INSERT INTO Soutenance (confidentiel, Maitre_stage, note, reponse, id_statut, id_stage)
        VALUES (?, ?, ?, ?, ?, ?)
    """, confidentiel, maitreStage, note, reponse, statutId, idStage);

    return jdbc.queryForObject("SELECT currval(pg_get_serial_sequence('soutenance','id_soutenance'))", Integer.class);
}

public int updateSoutenance(int idSoutenance, Boolean confidentiel, Boolean maitreStage,
                            java.math.BigDecimal note, Boolean reponse, Integer statutId) {
    return jdbc.update("""
        UPDATE Soutenance
        SET confidentiel = ?, Maitre_stage = ?, note = ?, reponse = ?, id_statut = ?
        WHERE id_soutenance = ?
    """, confidentiel, maitreStage, note, reponse, statutId, idSoutenance);
}

public int updateEtudiant(int idEtudiant, String nom, String prenom) {
    return jdbc.update("""
        UPDATE Etudiant SET nom = ?, prenom = ? WHERE id_etudiant = ?
    """, nom, prenom, idEtudiant);
}

}

//En Spring, une Repository est une interface qui sert à interagir avec la base de données. 
//Elle fait partie de la couche DAO (Data Access Object) et permet de lire, 
//écrire, modifier ou supprimer des données sans avoir à écrire du SQL manuellement.

